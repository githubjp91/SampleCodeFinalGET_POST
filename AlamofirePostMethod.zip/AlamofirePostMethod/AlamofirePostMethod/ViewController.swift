//
//  ViewController.swift
//  AlamofirePostMethod
//
//  Created by Mac on 9/14/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       /*
         
         Alamofire.request("link", method:.post, parameter:params).responseJSON{response in
         
         switch response.result
         {
         case . success:
         let json = JSON(response.result.value)
         print(json)
         
         case .failure( _):
         var erroestring = "NULL"
         if let data = response.data
         {
         if let json = try? JSONSerialization.jsonObject(with: data, option:[])as! [String:String]
         {errorString = json["error"]!
         }
         }
         
         
         */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    /*
     
     func get()
     {
     
     guard let url = URL(string:"link")else{return}
     let session = URLSession.shared.dataTask(with:url){(data,response,error) in
     
     
     if let response = response
     {
     print(response)
     if let data = data
     {
     do
     {
     var json = try JSONSerialization.jsonObject(with:data , options:[])
     print(json)
     for (i,j) in json as! [String:AnyObject]
     {
     print(j)
     }
     
     
     
     
     }
     catch{
     print(error.localizedDescription)
     }
     }
     }
     
     
     
     
     
     
     
     
     
     
     
     */
    
    
    
}

